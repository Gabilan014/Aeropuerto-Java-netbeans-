package Aeropuertos.Model.Repository;

import Aeropuertos.Model.Entity.Aeropuerto;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;

/**
 Principio de Sustitución de Liskov (LSP - Liskov Substitution Principle)
Las subclases deben poder sustituir a sus superclases sin alterar el comportamiento del programa.

Ejemplo en AeropuertoDaoImpl implementando AeropuertoDao
* 
* Cumple LSP porque AeropuertoDaoImpl implementa AeropuertoDao,
  lo que permite que cualquier clase que use la interfaz (AeropuertoController, por ejemplo) funcione con cualquier implementación sin problemas.
*/
public class AeropuertoDaoImpl implements AeropuertoDao {

    private EntityManagerFactory emf;
    private EntityManager em;

    public AeropuertoDaoImpl() {
        this.emf = Persistence.createEntityManagerFactory("proyecto-final-vuelosPU");
        this.em = emf.createEntityManager();
    }

    @Override
    public void createAeropuerto(Aeropuerto aeropuerto) {
        try {
            em.getTransaction().begin();
            em.persist(aeropuerto);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void updateAeropuerto(Aeropuerto aeropuerto, int id) {
        try {
            em.getTransaction().begin();
            em.merge(aeropuerto);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteAeropuerto(int id) {
        try {
            if (!em.getTransaction().isActive()) {
                em.getTransaction().begin(); // Si no está activa, iniciamos la transacción
            }

            Aeropuerto aeropuerto = em.find(Aeropuerto.class, id);
            if (aeropuerto != null) {
                em.remove(aeropuerto);
            }

            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback(); // Rollback si la transacción está activa
            }
            e.printStackTrace();
        }
    }

    public Aeropuerto searchAeropuertoByName(String nombre) {
        try {
            return (Aeropuerto) em.createQuery("SELECT a FROM Aeropuerto a WHERE a.nombre = :nombre")
                    .setParameter("nombre", nombre)
                    .getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Override
    public Aeropuerto searchAeropuerto(int id) {
        Aeropuerto aeropuerto = null;
        try {
            aeropuerto = em.find(Aeropuerto.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return aeropuerto;
    }

    @Override
    public List<Aeropuerto> readAll() {
        List<Aeropuerto> aeropuertos = null;
        try {
            aeropuertos = em.createQuery("SELECT a FROM Aeropuerto a", Aeropuerto.class).getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return aeropuertos;
    }

    public void close() {
        if (em.isOpen()) {
            em.close();
        }
        if (emf.isOpen()) {
            emf.close();
        }
    }
}
