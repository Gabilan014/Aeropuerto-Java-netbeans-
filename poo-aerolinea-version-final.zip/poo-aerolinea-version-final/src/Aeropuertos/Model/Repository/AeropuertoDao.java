package Aeropuertos.Model.Repository;

import Aeropuertos.Model.Entity.Aeropuerto;
import java.util.List;

/*
 Principio de Abierto/Cerrado (OCP - Open/Closed Principle)
El código debe estar abierto para extensión pero cerrado para modificación.

 Ejemplo en AeropuertoDao (Interfaz de DAO)

Cumple OCP porque cualquier nueva implementación del DAO (AeropuertoDaoImpl, AeropuertoDaoMySQLImpl, etc.) puede extender el comportamiento sin modificar la interfaz existente.
*/

/*
 Principio de Segregación de Interfaces (ISP - Interface Segregation Principle)
Las interfaces deben ser específicas para evitar que las clases implementen métodos que no usan.

Cumple ISP porque no obliga a las clases a implementar métodos innecesarios, solo los esenciales para manejar aeropuertos.

*/
public interface AeropuertoDao {

    public void createAeropuerto(Aeropuerto aeropuerto);

    public void updateAeropuerto(Aeropuerto aeropuerto, int id);

    public void deleteAeropuerto(int id);

    public Aeropuerto searchAeropuertoByName(String nombre);

    public Aeropuerto searchAeropuerto(int id);

    public List<Aeropuerto> readAll();
}
