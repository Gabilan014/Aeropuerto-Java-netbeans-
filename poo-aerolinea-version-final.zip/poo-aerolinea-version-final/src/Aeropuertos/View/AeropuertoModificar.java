package Aeropuertos.View;

import Aeropuertos.Controller.AeropuertoController;
import Aeropuertos.Model.Entity.Aeropuerto;
import Aeropuertos.Model.Repository.AeropuertoDao;
import Aeropuertos.Model.Repository.AeropuertoDaoImpl;
import Vuelos.view.VueloModificar;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class AeropuertoModificar extends javax.swing.JFrame {

    private final AeropuertoController controller;
    private AeropuertosABM aeropuertosAbm;
    public Aeropuerto aeropuertoExistente;
    public String nombreAeropuerto;

    public AeropuertoModificar(AeropuertoController controller, AeropuertosABM aeropuertosAbm, Aeropuerto aeropuertoExistente, String nombreAeropuerto) {
        initComponents();
        setSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize());
        getContentPane().setBackground(Color.CYAN);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.controller = controller;
        this.aeropuertosAbm = aeropuertosAbm;
        this.aeropuertoExistente = aeropuertoExistente;
        this.nombreAeropuerto = nombreAeropuerto;
        cargarDatosAeropuerto(aeropuertoExistente);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNombreAeropuerto = new javax.swing.JLabel();
        lblCiudadAeropuerto = new javax.swing.JLabel();
        txtNombreAeropuerto = new javax.swing.JFormattedTextField();
        txtCiudadAeropuerto = new javax.swing.JFormattedTextField();
        btnCancelar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblNombreAeropuerto.setText("Nombre del Aeropuerto:");

        lblCiudadAeropuerto.setText("Ciudad:");

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblCiudadAeropuerto)
                        .addGap(141, 141, 141)
                        .addComponent(txtCiudadAeropuerto))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblNombreAeropuerto, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(46, 46, 46)
                        .addComponent(txtNombreAeropuerto, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(98, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnCancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnGuardar)
                .addGap(22, 22, 22))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNombreAeropuerto)
                    .addComponent(txtNombreAeropuerto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCiudadAeropuerto)
                    .addComponent(txtCiudadAeropuerto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 75, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCancelar)
                    .addComponent(btnGuardar))
                .addGap(44, 44, 44))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        int confirm = JOptionPane.showConfirmDialog(
                this,
                "¿Está seguro de que desea cancelar la edición?",
                "Confirmación",
                JOptionPane.YES_NO_OPTION
        );
        if (confirm == JOptionPane.YES_OPTION) {
            this.dispose();
        }
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        try {
            // Obtenemos los datos ingresados en el formulario
            String nombre = txtNombreAeropuerto.getText().trim();
            String ciudad = txtCiudadAeropuerto.getText().trim();

            // Validamos que los campos no estén vacíos
            if (nombre.isEmpty() || ciudad.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Todos los campos deben ser completos.");
                return;
            }

            // Actualizamos el aeropuerto con los nuevos valores
            aeropuertoExistente.setNombre(nombre);
            aeropuertoExistente.setCiudad(ciudad);

            controller.updateAeropuerto(aeropuertoExistente.getId(), nombre, ciudad);

            // Refrescamos la vista principal y cerramos esta ventana
            aeropuertosAbm.mostrarAeropuertos();
            dispose();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error al guardar el aeropuerto: " + e.getMessage());
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    public void cargarDatosAeropuerto(Aeropuerto aeropuertoExistente) {
        txtNombreAeropuerto.setText(aeropuertoExistente.getNombre());
        txtCiudadAeropuerto.setText(aeropuertoExistente.getCiudad());
    }

    public void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VueloModificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VueloModificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VueloModificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VueloModificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                AeropuertoController aeropuertoController = new AeropuertoController();
                AeropuertosABM aeropuertosAbm = new AeropuertosABM(aeropuertoController);
                Aeropuerto aeropuertoExistente = controller.searchAeropuertoNombre(nombreAeropuerto);
                new AeropuertoModificar(aeropuertoController, aeropuertosAbm, aeropuertoExistente, aeropuertoExistente.getNombre()).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JLabel lblCiudadAeropuerto;
    private javax.swing.JLabel lblNombreAeropuerto;
    private javax.swing.JFormattedTextField txtCiudadAeropuerto;
    private javax.swing.JFormattedTextField txtNombreAeropuerto;
    // End of variables declaration//GEN-END:variables
}
