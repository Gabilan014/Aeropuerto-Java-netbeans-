package Aeropuertos.View;

import Aeropuertos.Controller.AeropuertoController;
import java.awt.Color;
import javax.swing.JFrame;

public class AeropuertosAñadir extends javax.swing.JFrame {

    private final AeropuertoController controladora;
    private AeropuertosABM aeropuertoAbm = null;

    public AeropuertosAñadir(AeropuertoController aeropuertoController, AeropuertosABM aeropuertoAbm) {
        initComponents();
        // Establecer el tamaño de la ventana
        setSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize()); // Usa el tamaño de pantalla completo
        // Cambiar el color de fondo
        getContentPane().setBackground(Color.CYAN);  // Puedes elegir el color que desees
        // Establecer la acción de cerrar cuando se presiona el botón de cerrar
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.controladora = aeropuertoController;
        this.aeropuertoAbm = aeropuertoAbm;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNombreAeropuerto = new javax.swing.JLabel();
        lblCiudadAeropuerto = new javax.swing.JLabel();
        txtNombreAeropuerto = new javax.swing.JFormattedTextField();
        txtCiudadAeropuerto = new javax.swing.JFormattedTextField();
        btnCancelar = new javax.swing.JButton();
        btnAgregar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblNombreAeropuerto.setText("Nombre del Aeropuerto: ");

        lblCiudadAeropuerto.setText("Ciudad:");

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblNombreAeropuerto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblCiudadAeropuerto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtCiudadAeropuerto, javax.swing.GroupLayout.DEFAULT_SIZE, 323, Short.MAX_VALUE)
                    .addComponent(txtNombreAeropuerto))
                .addContainerGap(81, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnCancelar)
                .addGap(18, 18, 18)
                .addComponent(btnAgregar)
                .addGap(38, 38, 38))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNombreAeropuerto)
                    .addComponent(txtNombreAeropuerto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCiudadAeropuerto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCiudadAeropuerto))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 175, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCancelar)
                    .addComponent(btnAgregar))
                .addGap(44, 44, 44))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        aeropuertoAbm.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        String nombreAeropuerto = txtNombreAeropuerto.getText();
        String ciudad = txtCiudadAeropuerto.getText();

        controladora.addAeropuerto(nombreAeropuerto, ciudad);

        txtNombreAeropuerto.setText("");
        txtCiudadAeropuerto.setText("");

        aeropuertoAbm.mostrarAeropuertos();
        this.setVisible(false);
    }//GEN-LAST:event_btnAgregarActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            System.err.println("Error al configurar el Look and Feel: " + ex.getMessage());
            ex.printStackTrace();
        }

        java.awt.EventQueue.invokeLater(() -> {
            try {
                AeropuertoController aeropuertoController = new AeropuertoController();
                AeropuertosABM aeropuertosABM = new AeropuertosABM(aeropuertoController);
                new AeropuertosAñadir(aeropuertoController, aeropuertosABM).setVisible(true);
            } catch (Exception e) {
                System.err.println("Error al iniciar la aplicación: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JLabel lblCiudadAeropuerto;
    private javax.swing.JLabel lblNombreAeropuerto;
    private javax.swing.JFormattedTextField txtCiudadAeropuerto;
    private javax.swing.JFormattedTextField txtNombreAeropuerto;
    // End of variables declaration//GEN-END:variables
}
