package Vuelos.model.repository;

import Vuelos.model.entity.Vuelo;
import java.util.List;

public interface VueloDao {

    public void createVuelo(Vuelo vuelo);

    public void updateVuelo(Vuelo vuelo, int id);

    public void deleteVuelo(int id);

    public Vuelo searchVuelo(int id);
    
    public Vuelo searchVueloNro(String nroVuelo);
    
    public List<Vuelo> readAll();
}
