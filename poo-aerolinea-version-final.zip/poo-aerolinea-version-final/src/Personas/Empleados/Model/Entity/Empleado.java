package Personas.Empleados.Model.Entity;

import Vuelos.model.entity.Vuelo;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "empleados")
public class Empleado extends Personas.Persona{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int empleadoId;
    @Column(name = "puesto_de_trabajo", nullable = false)
    protected String puestoDeTrabajo;
    @JoinColumn(name = "vuelo", nullable = false)
    protected Vuelo vuelo;
    @Column(name = "avion", nullable = false)
    protected String avion;

    public Empleado(String puestoDeTrabajo, Vuelo vuelo, String avion, String nombre, String apellido, long dni) {
        super(nombre, apellido, dni);
        this.puestoDeTrabajo = puestoDeTrabajo;
        this.vuelo = vuelo;
        this.avion = avion;
    }

    public Empleado() {
    }

    public int getEmpleadoId() {
        return empleadoId;
    }

    public void setEmpleadoId(int empleadoId) {
        this.empleadoId = empleadoId;
    }

    public String getPuestoDeTrabajo() {
        return puestoDeTrabajo;
    }

    public void setPuestoDeTrabajo(String puestoDeTrabajo) {
        this.puestoDeTrabajo = puestoDeTrabajo;
    }

    public Vuelo getVuelo() {
        return vuelo;
    }

    public void setVuelo(Vuelo vuelo) {
        this.vuelo = vuelo;
    }

    public String getAvion() {
        return avion;
    }

    public void setAvion(String avion) {
        this.avion = avion;
    }

    

    @Override
    public String toString() {
        return "Empleado{" + "puestoDeTrabajo=" + puestoDeTrabajo + ", vuelo=" + vuelo + ", avion=" + avion + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 43 * hash + Objects.hashCode(this.puestoDeTrabajo);
        hash = 43 * hash + Objects.hashCode(this.vuelo);
        hash = 43 * hash + Objects.hashCode(this.avion);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Empleado other = (Empleado) obj;
        if (!Objects.equals(this.puestoDeTrabajo, other.puestoDeTrabajo)) {
            return false;
        }
        if (!Objects.equals(this.vuelo, other.vuelo)) {
            return false;
        }
        return Objects.equals(this.avion, other.avion);
    }

}
