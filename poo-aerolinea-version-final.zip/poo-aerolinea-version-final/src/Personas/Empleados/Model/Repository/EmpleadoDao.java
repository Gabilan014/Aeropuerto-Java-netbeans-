package Personas.Empleados.Model.Repository;

import Personas.Empleados.Model.Entity.Empleado;
import java.util.List;

public interface EmpleadoDao {
    
    public void createEmpleado(Empleado empleado);

    public void updateEmpleado(Empleado empleado, int id);

    public void deleteEmpleado(int id);

    public Empleado searchEmpleado(int id);

    public List<Empleado> readAll();
}
