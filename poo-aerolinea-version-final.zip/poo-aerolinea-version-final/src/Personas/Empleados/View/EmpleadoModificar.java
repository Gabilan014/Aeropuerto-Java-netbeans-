package Personas.Empleados.View;

import Personas.Empleados.Controller.EmpleadoController;
import Personas.Empleados.Model.Entity.Empleado;
import Personas.Empleados.Model.Repository.EmpleadoDaoImpl;
import Vuelos.controller.VueloController;
import Vuelos.model.entity.Vuelo;
import Vuelos.model.repository.VueloDaoImpl;
import javax.swing.JOptionPane;

/**
 *
 * @author usuario
 */
public class EmpleadoModificar extends javax.swing.JFrame {

    private Empleado empleadoExistente = null;
    private VueloController vueloController;
    private EmpleadoController controller;
    private EmpleadoABM empleadoAbm;
    
    
    public EmpleadoModificar(Empleado empleadoExistente, VueloController vueloController, EmpleadoController controller, EmpleadoABM empleadoABM) {
        this.empleadoExistente = empleadoExistente;
        this.vueloController = vueloController;
        this.controller = controller;
        this.empleadoAbm = empleadoABM;
        initComponents();
        CargarDatos(empleadoExistente);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtDni = new javax.swing.JFormattedTextField();
        btnGuardar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        lblNombre = new javax.swing.JLabel();
        lblApellido = new javax.swing.JLabel();
        lblDni = new javax.swing.JLabel();
        lblPuestoTrabajo = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        lblAvion = new javax.swing.JLabel();
        txtVuelo = new javax.swing.JFormattedTextField();
        txtAvion = new javax.swing.JTextField();
        lblVuelo = new javax.swing.JLabel();
        cbPuestoTrabajo = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtDni.setEditable(false);

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        lblNombre.setText("Nombre:");

        lblApellido.setText("Apellido:");

        lblDni.setText("Dni:");

        lblPuestoTrabajo.setText("Puesto de trabajo:");

        txtNombre.setEditable(false);

        txtApellido.setEditable(false);

        lblAvion.setText("Avion:");

        lblVuelo.setText("Vuelo:");

        cbPuestoTrabajo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Piloto", "Co-Piloto", "Auxiliar de vuelo", " " }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(440, Short.MAX_VALUE)
                .addComponent(btnGuardar)
                .addGap(18, 18, 18)
                .addComponent(btnCancelar)
                .addGap(401, 401, 401))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblNombre, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblApellido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblDni, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblPuestoTrabajo, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtDni, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)
                            .addComponent(txtApellido)
                            .addComponent(txtNombre)
                            .addComponent(cbPuestoTrabajo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblVuelo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblAvion, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtAvion)
                            .addComponent(txtVuelo, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNombre)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblApellido)
                    .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDni)
                    .addComponent(txtDni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPuestoTrabajo)
                    .addComponent(cbPuestoTrabajo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblVuelo)
                    .addComponent(txtVuelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAvion)
                    .addComponent(txtAvion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar)
                    .addComponent(btnCancelar))
                .addContainerGap(169, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        int idEmpleado = empleadoExistente.getEmpleadoId();
        String nombre = txtNombre.getText().trim();
        String apellido = txtApellido.getText().trim();
        String dni = txtDni.getText().replace(".", "").trim();
        String puestoDeTrabajo = (String) cbPuestoTrabajo.getSelectedItem();
        String nroVuelo = txtVuelo.getText().trim();
        String avion = txtAvion.getText().trim();
        Vuelo vueloEmpleado;
        
        // Verifica si algún campo está vacío
        if (nombre.isEmpty() || apellido.isEmpty() || dni.isEmpty() || puestoDeTrabajo.isEmpty() || nroVuelo.isEmpty() || avion.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos deben estar completos.",
                "Error de validación", JOptionPane.WARNING_MESSAGE);
            return; // Sale del método si algún campo está vacío
        }

        // Verifica si el número de vuelo existe
        if (vueloController.searchVueloNroVuelo(nroVuelo) == null) {
            JOptionPane.showMessageDialog(this, "El número de vuelo asignado no existe.",
                "Error de validación", JOptionPane.ERROR_MESSAGE);
            return; // Sale del método si el vuelo no existe
        }
        else{
            vueloEmpleado = vueloController.searchVueloNroVuelo(nroVuelo);
        }

        // Si todas las verificaciones pasan, actualiza el pasajero
        controller.updateEmpleado(puestoDeTrabajo, vueloEmpleado, avion, idEmpleado);
        empleadoAbm.mostrarEmpleados();
        this.dispose(); // Cierra la ventana
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnCancelarActionPerformed

    public void CargarDatos(Empleado empleadoExistente) {
        txtNombre.setText(empleadoExistente.getNombre());
        txtApellido.setText(empleadoExistente.getApellido());
        Long dni = empleadoExistente.getDni();
        String stringDni = dni.toString();
        txtDni.setText(stringDni);
        txtVuelo.setText(empleadoExistente.getVuelo().getNroVuelo());
        txtAvion.setText(empleadoExistente.getAvion());
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmpleadoModificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmpleadoModificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmpleadoModificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmpleadoModificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Empleado empleado = new Empleado();
                VueloDaoImpl vueloDaoImpl = new VueloDaoImpl();
                VueloController vueloController = new VueloController(vueloDaoImpl);
                EmpleadoDaoImpl empleadoDaoImpl = new EmpleadoDaoImpl();
                EmpleadoController empleadoController = new EmpleadoController(empleadoDaoImpl);
                EmpleadoABM empleadoABM = new EmpleadoABM(empleadoDaoImpl,empleadoController);
                new EmpleadoModificar(empleado,vueloController,empleadoController,empleadoABM).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JComboBox<String> cbPuestoTrabajo;
    private javax.swing.JLabel lblApellido;
    private javax.swing.JLabel lblAvion;
    private javax.swing.JLabel lblDni;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblPuestoTrabajo;
    private javax.swing.JLabel lblVuelo;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtAvion;
    private javax.swing.JFormattedTextField txtDni;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JFormattedTextField txtVuelo;
    // End of variables declaration//GEN-END:variables
}
