package Personas.Pasajeros.Controller;

import Personas.Pasajeros.Model.Entity.Pasajero;
import Personas.Pasajeros.Model.Repository.PasajeroDaoImpl;
import Vuelos.model.entity.Vuelo;
import Vuelos.model.repository.VueloDaoImpl;
import java.util.List;

/**
 * Controladora que gestiona las operaciones relacionadas con los pasajeros.
 * Permite agregar, eliminar, actualizar y listar pasajeros, además de interactuar con los vuelos asignados.
 */
public class PasajeroController {

    private PasajeroDaoImpl pasajeroDaoImpl;
    private VueloDaoImpl vueloDao;

    /**
     * Constructor que inicializa la controladora con implementaciones personalizadas
     * de {@link PasajeroDaoImpl} y {@link VueloDaoImpl}.
     *
     * @param pasajeroDaoImpl instancia de {@link PasajeroDaoImpl} para gestionar los pasajeros.
     * @param vueloDaoImpl    instancia de {@link VueloDaoImpl} para gestionar los vuelos.
     */
    public PasajeroController(PasajeroDaoImpl pasajeroDaoImpl, VueloDaoImpl vueloDaoImpl) {
        this.pasajeroDaoImpl = pasajeroDaoImpl;
        this.vueloDao = vueloDaoImpl;
    }

    /**
     * Constructor por defecto que inicializa la controladora con implementaciones predeterminadas
     * de {@link PasajeroDaoImpl} y {@link VueloDaoImpl}.
     */
    public PasajeroController() {
        this.pasajeroDaoImpl = new PasajeroDaoImpl();
        this.vueloDao = new VueloDaoImpl();
    }

    /**
     * Agrega un nuevo pasajero al sistema.
     *
     * @param nombre        el nombre del pasajero.
     * @param apellido      el apellido del pasajero.
     * @param dni           el DNI del pasajero.
     * @param vueloPasajero el vuelo asignado al pasajero.
     */
    public void addPasajero(String nombre, String apellido, long dni, Vuelo vueloPasajero) {
        Pasajero pasajero = new Pasajero(nombre, apellido, dni, vueloPasajero);
        pasajeroDaoImpl.createPasajero(pasajero);
    }

    /**
     * Elimina un pasajero del sistema usando su ID.
     *
     * @param id el identificador único del pasajero a eliminar.
     */
    public void deletePasajero(int id) {
        pasajeroDaoImpl.deletePasajero(id);
    }

    /**
     * Actualiza los datos de un pasajero existente.
     *
     * @param idPasajero el identificador único del pasajero a actualizar.
     * @param nombre     el nuevo nombre del pasajero.
     * @param apellido   el nuevo apellido del pasajero.
     * @param dni        el nuevo DNI del pasajero (como cadena de texto).
     * @param nroVuelo   el número del nuevo vuelo asignado al pasajero.
     */
    public void updatePasajero(int idPasajero, String nombre, String apellido, String dni, String nroVuelo) {
        Pasajero pasajeroExistente = pasajeroDaoImpl.searchPasajero(idPasajero);
        pasajeroExistente.setNombre(nombre);
        pasajeroExistente.setApellido(apellido);
        Long dniLong = Long.parseLong(dni);
        pasajeroExistente.setDni(dniLong);

        Vuelo vueloPasajero = vueloDao.searchVueloNro(nroVuelo);
        pasajeroDaoImpl.updatePasajero(pasajeroExistente, idPasajero);
    }

    /**
     * Devuelve una lista con todos los pasajeros registrados en el sistema.
     *
     * @return una lista de pasajeros.
     */
    public List<Pasajero> listPasajero() {
        List<Pasajero> listaPasajeros = pasajeroDaoImpl.readAll();
        return listaPasajeros;
    }
}
