package Personas.Pasajeros.Model.Entity;

import Vuelos.model.entity.Vuelo;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "pasajeros")
public class Pasajero extends Personas.Persona{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int pasajeroId;
    
    @ManyToOne
    @JoinColumn(name = "idVuelo", nullable = false)
    private Vuelo vueloPasajero;
   
    public Pasajero(String nombre, String apellido, long dni, Vuelo vueloPasajero){
        super(nombre, apellido, dni);
        this.vueloPasajero = vueloPasajero;
    }
    public Pasajero() {
    }

    public int getPasajeroId() {
        return pasajeroId;
    }

    public void setPasajeroId(int pasajeroId) {
        this.pasajeroId = pasajeroId;
    }
    
    public Vuelo getVueloPasajero() {
        return vueloPasajero;
    }
    public void setVueloPasajero(Vuelo vueloPasajero) {
        this.vueloPasajero = vueloPasajero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public long getDni() {
        return dni;
    }

    public void setDni(long dni) {
        this.dni = dni;
    }

    @Override
    public String toString() {
        return "Pasajero{" + "vueloPasajero=" + vueloPasajero + '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Pasajero other = (Pasajero) obj;
        return Objects.equals(this.vueloPasajero, other.vueloPasajero);
    }
    
    
}
