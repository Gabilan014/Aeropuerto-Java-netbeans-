package Personas.Pasajeros.Model.Repository;

import Personas.Pasajeros.Model.Entity.Pasajero;
import java.util.List;

public interface PasajeroDao {

    public void createPasajero(Pasajero pasajero);

    public void updatePasajero(Pasajero pasajero, int id);

    public void deletePasajero(int id);

    public Pasajero searchPasajero(int id);

    public List<Pasajero> readAll();
}
