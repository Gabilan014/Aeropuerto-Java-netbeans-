package Personas.Pasajeros.Model.Repository;

import Personas.Pasajeros.Model.Entity.Pasajero;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class PasajeroDaoImpl implements PasajeroDao{
    
    private EntityManagerFactory emf;
    private EntityManager em;

    
    public PasajeroDaoImpl(){
        this.emf = Persistence.createEntityManagerFactory("proyecto-final-vuelosPU");
        this.em = emf.createEntityManager();
    }
    @Override
    public void createPasajero(Pasajero pasajero) {
         try {
            em.getTransaction().begin();
            em.persist(pasajero);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void updatePasajero(Pasajero pasajero, int id) {
        try {
            em.getTransaction().begin();
            Pasajero existingPasajero = em.find(Pasajero.class, id);
            if (existingPasajero != null) {
                existingPasajero.setNombre(pasajero.getNombre());
                existingPasajero.setApellido(pasajero.getApellido());
                existingPasajero.setDni(pasajero.getDni());
                existingPasajero.setVueloPasajero(pasajero.getVueloPasajero());
                em.merge(existingPasajero);
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deletePasajero(int id) {
         try {
            em.getTransaction().begin();
            Pasajero pasajero = em.find(Pasajero.class, id);
            if (pasajero != null) {
                em.remove(pasajero);
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        }
    }

    @Override
    public Pasajero searchPasajero(int id) {
        Pasajero pasajero = null;
        try {
            pasajero = em.find(Pasajero.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return pasajero;
    }

    @Override
    public List<Pasajero> readAll() {
        List<Pasajero> pasajeros = null;
        try {
            pasajeros = em.createQuery("SELECT p FROM Pasajero p", Pasajero.class).getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return pasajeros;
    }
 
}
