package Aviones.Model.Repository;

public interface AvionDao {
    
}
