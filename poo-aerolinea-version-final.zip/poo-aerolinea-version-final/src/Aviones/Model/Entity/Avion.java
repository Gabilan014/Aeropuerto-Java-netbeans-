package Aviones.Model.Entity;

import Aeropuertos.Model.Entity.Aeropuerto;
import Vuelos.model.entity.Vuelo;
import java.util.Objects;

public class Avion {
    protected int matricula;
    protected String modelo;
    protected int capacidad;
    protected Aeropuerto aeropuertoSalida;
    protected Aeropuerto aeropuertoLlegada;
    protected Vuelo vuelo;

    public Avion(int matricula, String modelo, int capacidad, Aeropuerto aeropuertoSalida, Aeropuerto aeropuertoLlegada, Vuelo vuelo) {
        this.matricula = matricula;
        this.modelo = modelo;
        this.capacidad = capacidad;
        this.aeropuertoSalida = aeropuertoSalida;
        this.aeropuertoLlegada = aeropuertoLlegada;
        this.vuelo = vuelo;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public Aeropuerto getAeropuertoSalida() {
        return aeropuertoSalida;
    }

    public void setAeropuertoSalida(Aeropuerto aeropuertoSalida) {
        this.aeropuertoSalida = aeropuertoSalida;
    }

    public Aeropuerto getAeropuertoLlegada() {
        return aeropuertoLlegada;
    }

    public void setAeropuertoLlegada(Aeropuerto aeropuertoLlegada) {
        this.aeropuertoLlegada = aeropuertoLlegada;
    }

    public Vuelo getVuelo() {
        return vuelo;
    }

    public void setVuelo(Vuelo vuelo) {
        this.vuelo = vuelo;
    }

    @Override
    public String toString() {
        return "Avion{" + "matricula=" + matricula + ", modelo=" + modelo + ", capacidad=" + capacidad + ", aeropuertoSalida=" + aeropuertoSalida + ", aeropuertoLlegada=" + aeropuertoLlegada + ", vuelo=" + vuelo + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + this.matricula;
        hash = 97 * hash + Objects.hashCode(this.modelo);
        hash = 97 * hash + this.capacidad;
        hash = 97 * hash + Objects.hashCode(this.aeropuertoSalida);
        hash = 97 * hash + Objects.hashCode(this.aeropuertoLlegada);
        hash = 97 * hash + Objects.hashCode(this.vuelo);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Avion other = (Avion) obj;
        if (this.matricula != other.matricula) {
            return false;
        }
        if (this.capacidad != other.capacidad) {
            return false;
        }
        if (!Objects.equals(this.modelo, other.modelo)) {
            return false;
        }
        if (!Objects.equals(this.aeropuertoSalida, other.aeropuertoSalida)) {
            return false;
        }
        if (!Objects.equals(this.aeropuertoLlegada, other.aeropuertoLlegada)) {
            return false;
        }
        return Objects.equals(this.vuelo, other.vuelo);
    }
    
    
}
